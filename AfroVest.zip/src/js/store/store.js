import '@ryangjchandler/spruce';

Spruce.store('app', {
    isSiderbarOpen: false
}, true);

export default Spruce;